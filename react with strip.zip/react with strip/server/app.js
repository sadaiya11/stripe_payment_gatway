const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const stripe = require('stripe')('sk_test_51PLGCWSICSXgyBZm5CLXhyyLbefHM2NQ32Eqbw9A050rtIQLudPEzJ0Ja3g95LbfTJCbpoRsVXaXufDS8JIHxi1F00fmsVVJV0');

const app = express();

app.use(bodyParser.json());
app.use(cors());

// checkout api
app.post('/api/create-checkout-session', async (req, res) => {
	try {
		const { products } = req.body;

		if (!products || products.length === 0) {
			return res.status(400).json({ error: 'Products are required' });
		}

		console.log()
		const lineItems = products.map((product) => ({
			price_data: {
				currency: 'inr',
				product_data: {
					name: product.title,
					images: [product.images[0]],
				},
				unit_amount: product.price * 100,
			},
			quantity: product.qnty,
		}));

		const session = await stripe.checkout.sessions.create({
			payment_method_types: ['card'], 
			line_items: lineItems,
			mode: 'payment',
			success_url: 'http://localhost:3000/success', 
			cancel_url: 'http://localhost:3000/cancel',
		});

		res.status(200).json({ id: session.id })
	} catch (error) {
		console.error('Error creating checkout session', error)
		res.status(500).json({ error: 'Internal Server Error' })
	}
});

app.listen(7000, () => {
	console.log('Server started on port 7000');
});
