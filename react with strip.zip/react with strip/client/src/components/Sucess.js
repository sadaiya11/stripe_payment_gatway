import React from 'react'

const Sucess = () => {
  return (
    <div>Sucess</div>
  )
}

export default Sucess